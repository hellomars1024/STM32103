#ifndef _MOTOR_H
#define _MOTOR_H

#include "stm32f10x.h"

#define MOTOR_LEFT_GPIO_PORT   							GPIOA
#define MOTOR_LEFT1_GPIO_PIN   							GPIO_Pin_2
#define MOTOR_LEFT2_GPIO_PIN   							GPIO_Pin_3
#define MOTOR_LEFT_RCC_APB2Periph_GPIOx 			RCC_APB2Periph_GPIOA

#define MOTOR_RIGHT_GPIO_PORT   							GPIOA
#define MOTOR_RIGHT1_GPIO_PIN   							GPIO_Pin_2
#define MOTOR_RIGHT2_GPIO_PIN   							GPIO_Pin_3
#define MOTOR_RIGHT_RCC_APB2Periph_GPIOx 			RCC_APB2Periph_GPIOA

void MotorGpioConfig(void);

void Forward(void);
void Backward(void);
void Stop(void);
void StopNow(void);
void ForwardTurnLeft(void);
void ForwardTurnRight(void);
void BackwardTurnLeft(void);
void BackwardTurnRight(void);
#endif /*_MOTOR_H*/

