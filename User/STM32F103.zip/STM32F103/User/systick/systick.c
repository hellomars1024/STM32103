#include "systick.h"

/*΢�λ*/
void SysTick_Delay_us(uint32_t count){
	uint32_t i;
	//72MƵ��
	SysTick_Config(72);

	for(i=0;i<count;i++){
		while(!((SysTick->CTRL) &(1<<16)));
	}
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
}

/*���λ*/
void SysTick_Delay_ms(uint32_t count){
	uint32_t i;
	SysTick_Config(72*1000);
	
	for(i=0;i<count;i++){
		while(!((SysTick->CTRL) &(1<<16)));
	}
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
}
