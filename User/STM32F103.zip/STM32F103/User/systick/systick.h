#ifndef _SYS_TICK
#define _SYS_TICK

/**ϵͳ��ʱ��*/
#include "stm32f10x.h"
#include "core_cm3.h"

void SysTick_Delay_us(uint32_t count);


void SysTick_Delay_ms(uint32_t count);
#endif /*_SYS_TICK*/
