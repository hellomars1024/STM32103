#ifndef _LED_H
#define _LED_H
#include "stm32f10x.h"

#define LED_GPIO_PORT   GPIOC
#define LED_GPIO_CLK    RCC_APB2Periph_GPIOC
#define LED_GPIO_Pin		GPIO_Pin_13


void LEDInit(void);
#endif  /*_LED_H*/
