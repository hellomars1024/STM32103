#include "sonar_hcsr04.h"
#include "../systick/systick.h"


void Ultrasonic_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;//Trig
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;//Echo
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;

    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Timer2_Config(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseInitStructure.TIM_Prescaler = 71;
    TIM_TimeBaseInitStructure.TIM_Period = 49999;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;

    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
}

uint32_t Distance_Calculate(uint32_t count)
{
    uint32_t Distance = 0;
    Distance = (uint32_t)(((float)count / 58) * 100);
    return Distance;
}

void scan_length(void){
		uint32_t count = 0;
    uint32_t Distance = 0;
	  Ultrasonic_Config();
    Timer2_Config();
		while(1)
    {
        GPIO_ResetBits(GPIOB, GPIO_Pin_8);//Ԥ������Trig����
        GPIO_SetBits(GPIOB, GPIO_Pin_8);
        SysTick_Delay_us(10);
        GPIO_ResetBits(GPIOB, GPIO_Pin_8);//����10us������
        TIM2->CNT = 0;
        while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == 0);
        TIM_Cmd(TIM2, ENABLE);
        while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9) == 1);
        TIM_Cmd(TIM2, DISABLE);
        count = TIM2->CNT;
        Distance = Distance_Calculate(count);
        printf("Distance = %d.", Distance / 100);
        printf("%d cm\n", Distance % 100);
        SysTick_Delay_us(500);
    }
}











