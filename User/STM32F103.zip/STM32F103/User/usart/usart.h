#ifndef _USART_H
#define _USART_H

#include "stm32f10x.h"
#include  <stdio.h>

#define USART_GPIO_TX_PORT 			GPIOA
#define USART_GPIO_TX_PIN  			GPIO_Pin_9
#define USART_GPIO_RX_PORT 			GPIOA
#define USART_GPIO_RX_PIN  			GPIO_Pin_10

//GPIOʱ�Ӷ˿�
#define USART_GPIO_CLK					RCC_APB2Periph_GPIOA



#define DEBUG_USARTx 						USART1
#define DEBUG_USART_CLK 				RCC_APB2Periph_USART1
#define DEBUG_USART_APBxClkCmd 	RCC_APB2PeriphClockCmd
//������
#define DEBUG_USART_BAUDRATE   	115200

#define DEBUG_USART_IRQ 				USART1_IRQn
#define DEBUG_USART_IRQHandler 	USART1_IRQHandler


void UsartConfig(void);

void UsartSendByteData(USART_TypeDef* pUSARTx,uint8_t data);

void UsartSendHalfWord(USART_TypeDef* pUSARTx,uint16_t data);

void UsartSendByteArray(USART_TypeDef* pUSARTx,uint8_t* arr,uint8_t lenth);

void UsartSendStr(USART_TypeDef* pUSARTx,uint8_t* str);

void UsartReceiveStr(void);
//USART_SendData(USART_TypeDef* USARTx, (uint8_t) ch);
//int32_t USART_ReceiveData(USART_TypeDef* USARTx);
#endif /*_USART_H*/

