#include "usart.h"


GPIO_InitTypeDef USART_GPIO_InitStructure;
USART_InitTypeDef USART_InitStructure;
NVIC_InitTypeDef   USART_NVIC_InitStructure;

static void NVICConfig(void)
	{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
			/* Enable and set EXTI0 Interrupt to the lowest priority */
		USART_NVIC_InitStructure.NVIC_IRQChannel = DEBUG_USART_IRQ;
		USART_NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
		USART_NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
		USART_NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&USART_NVIC_InitStructure);
	}

void UsartConfig(void)
	{
	//GPIOʱ��ʹ��
	RCC_APB2PeriphClockCmd(USART_GPIO_CLK,ENABLE);
	//USART����ʱ��ʹ��
	RCC_APB2PeriphClockCmd(DEBUG_USART_CLK,ENABLE);
		
	USART_GPIO_InitStructure.GPIO_Pin = USART_GPIO_TX_PIN;
	USART_GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	USART_GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(USART_GPIO_TX_PORT , &USART_GPIO_InitStructure);
	
	
	USART_GPIO_InitStructure.GPIO_Pin = USART_GPIO_RX_PIN;
	USART_GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
  GPIO_Init(USART_GPIO_RX_PORT , &USART_GPIO_InitStructure);
	

		
	USART_InitStructure.USART_BaudRate = DEBUG_USART_BAUDRATE;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_Mode = USART_Mode_Tx|USART_Mode_Rx;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;  
	
	USART_Init(DEBUG_USARTx, &USART_InitStructure);	
	//�����ж����ȼ�
	NVICConfig();
	//���ݽ����ж�
	USART_ITConfig(DEBUG_USARTx,USART_IT_RXNE,ENABLE);
	
	USART_Cmd(DEBUG_USARTx, ENABLE);
}

void UsartSendByteData(USART_TypeDef* pUSARTx,uint8_t data)
	{
		USART_SendData(pUSARTx,data);
		
		while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TXE)==RESET);
	}
	
void UsartSendHalfWord(USART_TypeDef* pUSARTx,uint16_t data){
	uint8_t temp_h,temp_l;
	temp_h=(data&0xff00) >> 8;
	temp_l= data&0xff;
	USART_SendData(pUSARTx,temp_h);
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TXE)==RESET);
		USART_SendData(pUSARTx,temp_l);
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TXE)==RESET);
}

void UsartSendByteArray(USART_TypeDef* pUSARTx,uint8_t* arr,uint8_t lenth)
	{
		uint8_t i;
		for(i=0;i<lenth;i++){
			UsartSendByteData(pUSARTx,arr[i]);
		}
	
		while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TXE)==RESET);
	}
	
void UsartSendStr(USART_TypeDef* pUSARTx,uint8_t* str){
	uint8_t i=0;
	do
	{
		UsartSendByteData(pUSARTx,*(str+i));
		i++;
	}while(*(str+i)!='\0');
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TXE)==RESET);
}	

void UsartReceiveStr(void){
	uint8_t* str;
	uint8_t i=0;
	do{
		*(str+i)=USART_ReceiveData(DEBUG_USARTx);
		i++;
	}while(USART_ReceiveData(DEBUG_USARTx)!='\0');
	 while(USART_GetFlagStatus(DEBUG_USARTx,USART_FLAG_RXNE)==RESET);
	 printf("%c",*str);
}

int fputc(int ch,FILE *f){
	UsartSendByteData(DEBUG_USARTx,(uint8_t)ch);
	while(USART_GetFlagStatus(DEBUG_USARTx,USART_FLAG_TXE)==RESET);
	return(ch);
}

int fgetc(FILE *f){
	while(USART_GetFlagStatus(DEBUG_USARTx,USART_FLAG_RXNE)==RESET);
	return (int)USART_ReceiveData(DEBUG_USARTx);
}




