
#include "pwm.h"

GPIO_InitTypeDef PWM_GPIO_InitStructure;
TIM_TimeBaseInitTypeDef  PWM_TIM_TimeBaseStructure;
TIM_OCInitTypeDef  PWM_TIM_OCInitStructure;

void TIM_PWM_Config(uint16_t period,uint16_t prescaler){
	RCC_APB2PeriphClockCmd(PWM_GPIO_CLK,ENABLE);
	
	RCC_APB1PeriphClockCmd(PWD_TIM_CLK,ENABLE);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	PWM_GPIO_InitStructure.GPIO_Pin=PWM_GPIO_PIN;
	PWM_GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	PWM_GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(PWM_GPIO_PORT,&PWM_GPIO_InitStructure);
	
  /* Time base configuration */
  PWM_TIM_TimeBaseStructure.TIM_Period = period;
  PWM_TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	 //Ԥ��Ƶϵ��Ϊ0����������Ԥ��Ƶ����ʱTIMER��Ƶ��Ϊ72MHz
  PWM_TIM_TimeBaseStructure.TIM_ClockDivision =TIM_CKD_DIV1;
  PWM_TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(PWM_TIMx, &PWM_TIM_TimeBaseStructure);
	
	
	  /* PWM1 Mode configuration: Channel1 */
  PWM_TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  PWM_TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  PWM_TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  PWM_TIM_OCxInit(PWM_TIMx, &PWM_TIM_OCInitStructure);

	
	PWM_TIM_OCxPreloadConfig(PWM_TIMx,TIM_OCPreload_Enable);
	
	TIM_Cmd(PWM_TIMx,ENABLE);
	
}


