#ifndef _PWM_H
#define _PWM_H

#include "stm32f10x.h"
//TIM4_CH1
#define PWM_TIMx  									TIM4
#define PWD_TIM_CLK									RCC_APB1Periph_TIM4		


#define PWM_GPIO_CLK								RCC_APB2Periph_GPIOB
#define PWM_GPIO_PORT 							GPIOB
#define PWM_GPIO_PIN								GPIO_Pin_6


//ͨ��
#define PWM_TIM_OCxInit    					TIM_OC1Init
#define PWM_TIM_OCxPreloadConfig 		TIM_OC1PreloadConfig
#define PWM_TIM_SetComparex     		TIM_SetCompare1


void TIM_PWM_Config(uint16_t prescaler,uint16_t period);

#endif /*_PWM_H*/
