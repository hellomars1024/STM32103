#ifndef _KEY_H
#define _KEY_H

#include "stm32f10x.h"
#define KEY_GPIO_PORT   GPIOA
#define KEY_GPIO_CLK    RCC_APB2Periph_GPIOA
#define KEY_GPIO_Pin		GPIO_Pin_0


void initKeyGpio(void);

#endif /*_KEY_H*/
