#include "./key.h"

void initKeyGpio(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(KEY_GPIO_CLK,ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = KEY_GPIO_Pin;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(KEY_GPIO_PORT , &GPIO_InitStructure);
}


